# Code Safari AI — GitHub Code Reviewer

## Product and implementation roadmap

This document describes the current Code Safari AI application and provides an implementation roadmap aligned with its existing interface and behavior. The application is a responsive, light cotton-candy-pink GitHub code review dashboard for Pastry World. It uses a local Python server to serve the frontend and forward review requests to an n8n test webhook.

## How to use this roadmap

1. Follow the six phases in order when rebuilding the application.
2. Each phase describes the intended UI or behavior, along with checks for verifying it.
3. Phase 5 requires the local Python server and an active n8n test webhook listener.
4. The navigation links for Github Connection, History, and API Docs are currently visual navigation items; they do not lead to implemented pages.

---

## Phase 1: Application foundation and visual design

### Goal

Create the responsive application shell, Pastry World branding, page content, and cotton-candy-pink visual theme.

### Requirements

- Use the supplied `CompanyLogo.jpg` asset for the Pastry World logo.
- Show “Pastry World” and “The Sweetest Escape” above the main application navigation.
- Display the page title “Code Safari AI — GitHub Code Reviewer” and a short description of the AI review service.
- Use a light pink background with a subtle grid, soft ambient pink glows, cocoa-colored text, rounded cards, and responsive spacing.
- Include a footer with “Pastry World” and the 2026 copyright notice.
- Use the existing system font fallbacks (Inter, Aptos, Segoe UI); no third-party JavaScript library is required.

### Verification

- Confirm the Pastry World logo loads and its name and tagline appear above the navigation.
- Confirm the dashboard uses a light pink palette, subtle grid, and ambient glows.
- Confirm the page title, explanatory text, and footer are present.
- Check that the page remains usable at desktop, tablet, and narrow mobile widths.

---

## Phase 2: Brand navigation and status indicators

### Goal

Place the application navigation below the company brand and present the product identity and connection/status indicators.

### Requirements

- Add a translucent, sticky navigation bar beneath the company header.
- Display a star icon, “Code Safari AI”, and the tagline “Thoughtful code reviews, powered by AI”.
- Show Dashboard as the active navigation item alongside Github Connection, History, and API Docs.
- Display an “n8n Connected” status badge using the same pink-family treatment as the active Dashboard item, plus a user avatar with “NS”.
- Treat “n8n Connected” as a static display badge; the current application does not perform a live connection check.
- Display the “Analysis Completed” badge after a successful review. Style it with the pink badge treatment and cocoa-colored status dot; hide it before a successful review and after reset or error.
- Keep the nav links to Github Connection, History, and API Docs as visual links unless those pages are implemented in a later change.

### Verification

- Confirm the company brand appears above the navigation bar.
- Confirm the navigation stays at the top while scrolling and adapts to smaller screens.
- Confirm Dashboard is styled as active and the n8n badge uses a matching pink color treatment.
- Confirm the completion badge only appears after a successful review.

---

## Phase 3: Review controls and dashboard layout

### Goal

Build the two-column review dashboard with a GitHub URL input, review/reset controls, informational Pro Plan card, and review workspace.

### Requirements

- On desktop, show the Github Analyzer card and Pro Plan card in the left sidebar, with the Review Code Workspace on the right. Reflow the layout on smaller screens.
- Provide a labeled GitHub URL input with the placeholder `e.g. https://github.com/`.
- Place “Review Code” and “Refresh” buttons next to each other. Give them matching pink gradient styling, equal height, and equal width.
- Keep the Pro Plan card informational; do not imply that purchasing or upgrading is implemented.
- In the workspace, initially show “Your code review starts here” and instructions to enter a GitHub URL and click Review Code.
- Do not show module-selection checkboxes; the review form submits the URL only.

### Verification

- Confirm the analyzer and workspace appear side-by-side on a wide screen and stack on a narrow screen.
- Confirm the URL field has a visible label and focus styling.
- Confirm Review Code and Refresh have matching colors and dimensions.
- Confirm the initial workspace shows the waiting illustration and guidance.

---

## Phase 4: Workspace loading, waiting, and error states

### Goal

Make the review workspace communicate its waiting, loading, and error states clearly.

### Requirements

- Show animated cyber spinner rings and a radar icon in the initial waiting state.
- While a review request is in progress, hide the waiting state, show the loading indicator and pink scan effect, and cycle the status text between “Reading Code...” and “Contacting Github...” every 1.5 seconds.
- For validation or request failures, show a clear error title and message in the workspace and use the error styling/shake effect.
- Hide the initial waiting instructions while displaying a review result or error.

### Verification

- Confirm the spinner is present before a review.
- Submit a valid URL and confirm the loading text and scan animation appear.
- Submit an empty or malformed URL and confirm an error is shown without sending a request.
- Confirm the waiting instructions are not visible behind a result or error.

---

## Phase 5: URL validation, n8n connection, and refresh behavior

### Goal

Connect the review form to the n8n workflow through the local same-origin Python server and handle request/response failures.

### Request flow

1. Run `python server.py` from the application directory. By default, the frontend is served at `http://localhost:8000`.
2. The browser sends a JSON `POST` request to `/api/review` with the shape `{ "githubUrl": "<URL>" }`.
3. The Python server forwards the request to `http://localhost:5678/webhook-test/GithubCode_Reviewer`.
4. The n8n test workflow must be listening when the request is submitted. A test webhook listener may be one-shot and need to be started again.
5. For GitHub file links in the form `https://github.com/OWNER/REPOSITORY/blob/BRANCH/PATH`, the frontend changes the host to `raw.githubusercontent.com` and forwards the raw-file URL. Other entered URLs are forwarded as entered.

### Requirements

- Prevent empty submissions and show “Please enter a GitHub URL.”
- Parse the entered value as an absolute URL and allow only `http:` and `https:` protocols. Show a helpful error for malformed values or other protocols.
- Do not claim this client-side check verifies that the host is GitHub; it checks URL syntax and protocol.
- During the request, disable the input and both buttons, change the submit label to “Analyzing...”, hide any prior result, and start the loading state.
- Send the URL as JSON using `Content-Type: application/json`.
- Accept plain-text or JSON responses. Extract readable text from common response fields and nested arrays/objects.
- Show a connection error if the server or webhook returns an unsuccessful status, cannot be reached, times out, or returns an empty response.
- Always stop the progress ticker and re-enable the input and buttons when the request finishes.
- The Refresh button clears the entered URL, validation error, result/error, and completion badge; restores the initial waiting workspace; and focuses the URL field. It is disabled while a request is running.

### Verification

- Submit an empty value and a malformed value; verify each shows an error and does not send a review request.
- With the local server running, inspect the browser Network panel and confirm a `POST` to `/api/review` with a `githubUrl` JSON property.
- Confirm the server forwards requests to the configured n8n test webhook and that the n8n test workflow is actively listening.
- Confirm GitHub `/blob/` links are converted to `raw.githubusercontent.com` URLs before forwarding.
- Simulate or observe an upstream failure and confirm a visible error appears and controls become usable again.
- Click Refresh after entering a URL and after a completed review; confirm the form and workspace return to their initial state.

---

## Phase 6: Review formatting and completed results

### Goal

Render the n8n review response as a readable, safely constructed report, then display a completion state.

### Requirements

- Set the result heading to “Code Reviewed”.
- Render Markdown headings, bold and italic text, inline code, fenced code blocks, unordered/ordered lists, and tables without external libraries.
- Construct report elements and text nodes rather than inserting response content as raw HTML.
- Remove `<br>` tags from the response and use the following lines as separate points where appropriate.
- When a review is structured as categories and a table, keep each category’s review points together in its Description cell and keep that category’s score in the Score column.
- Display “Score” and “(out of 20)” on separate lines in the table header.
- Extract “Overall Score” from the review and render it as a separate bold score section above “Improvement Areas & Actionable Recommendations”.
- Remove horizontal-rule separators such as `---` from the displayed report.
- Omit the “Actionable Feedback & Recommendations” section from the rendered review. Retain and display “Improvement Areas & Actionable Recommendations” when present.
- On successful rendering, show the “Analysis Completed” badge and fade in the report.
- After success, keep the input available for another review. Refresh clears the current result and returns to the waiting state.

### Verification

- Confirm a successful response is titled “Code Reviewed” and reveals the formatted report.
- Confirm category points remain in the Description cell and the corresponding score is in the Score column.
- Confirm “(out of 20)” appears below “Score”.
- Confirm Overall Score is bold, displayed separately, and appears above Improvement Areas.
- Confirm horizontal-rule lines and the Actionable Feedback & Recommendations section are not displayed.
- Confirm `<br>` tags are not displayed literally and their content remains readable as points.
- Confirm markup-like input is displayed as text rather than interpreted as HTML.
- Confirm the Analysis Completed badge appears on success and that another review can be submitted.

---

## Current architecture

- **Frontend:** HTML, CSS, and vanilla JavaScript (`index.html`, `styles.css`, `app.js`).
- **Review rendering:** Small built-in Markdown renderer using DOM elements and text nodes; no external JavaScript dependencies.
- **Local server and proxy:** Python standard-library HTTP server (`server.py`), serving the frontend and forwarding `POST /api/review`.
- **Workflow:** n8n test webhook at `http://localhost:5678/webhook-test/GithubCode_Reviewer`; it must be active to handle a test request.
- **Brand asset:** `CompanyLogo.jpg`.
